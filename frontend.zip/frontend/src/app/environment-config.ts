// ServiceBase URL to handle backend requests
export const SERVICE_BASE_URL = 'http://localhost:8080'


// BaseUrl to handle frontend requests
export const UI_BASE_URL = 'http://localhost:4200'

