export interface LoginResponseModule {
    isLogged: boolean;
    role: string;
    name: string;
  }

